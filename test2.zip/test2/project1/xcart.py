from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from unittest.test.testmock.testpatch import function

#opt=webdriver.ChromeOptions()
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path)
driver.implicitly_wait(15)
driver.maximize_window()

driver.get("https://demostore.x-cart.com/")

cartsearch=driver.find_elements_by_xpath("//div[@class='table-value substring-value']/span/input")
#print (len(cartsearch))
cartsearch[0].send_keys("toys")
#cartsearch1.click()
#cartsearch1.send_keys("shirt")
cartsearch1=driver.find_element_by_xpath("//button[@class='btn  regular-button submit-button submit']")
cartsearch1.click()
cartsearch2=driver.find_element_by_xpath("//a[@class='product-thumbnail next-previous-assigned']")
cartsearch2.click()
cartsearch3=driver.find_element_by_xpath("//button[@class='btn  regular-button regular-main-button add2cart submit']")
cartsearch3.click()
#closebar=driver.find_element_by_xpath("//button[@class='ui-dialog-titlebar-close']")
#closebar.click()
#cartclick=driver.find_element_by_xpath("//div[@id='header']")
#cartclick.click()
sleep(5)
checkoutorder=driver.find_elements_by_xpath("//a[@class='regular-main-button checkout']")
print (len(checkoutorder))
checkoutorder[1].click()
accuser=driver.find_element_by_xpath("//input[@id='email']")
accuser.send_keys("kumar@gmail.com")
#accpass=driver.find_element_by_xpath("//input[@id='login-email']")
#accpass[0].send_keys("kuamr@123")
acccontinue=driver.find_element_by_xpath("//button[@class='btn  regular-button anonymous-continue-button submit']")
acccontinue.click()
shipfname=driver.find_element_by_xpath("//input[@id='shippingaddress-firstname']")
shipfname.send_keys("kumar")
shiplname=driver.find_element_by_xpath("//input[@id='shippingaddress-lastname']")
shiplname.send_keys("kishor")
shipadd=driver.find_element_by_xpath("//input[@id='shippingaddress-street']")
shipadd.send_keys("EC")
shipcity=driver.find_element_by_xpath("//input[@id='shippingaddress-city']")
shipcity.clear()
shipcity.send_keys("banglore")
shipctry=driver.find_element_by_xpath("//select[@id='shippingaddress-country-code']")
shipctry.send_keys("India")
driver.execute_script("arguments[0].scrollIntoView(true);",shipctry)
shipstate=driver.find_element_by_xpath("//select[@id='shippingaddress-state-id']")
shipstate.send_keys("Karnataka")
shippin=driver.find_element_by_xpath("//input[@id='shippingaddress-zipcode']")
shippin.clear()
shippin.send_keys("560100")
#shipdel=driver.find_elements_by_xpath("//span[@class='rate-title']")
#driver.execute_script("arguments[0].scrollIntoView(true);",shipdel)
#shipdel[2].click()
sleep(5)
shipdel=driver.find_elements_by_xpath("//span[@class='rate-title']")
shipdel[2].click()
sleep(5)
shippay=driver.find_element_by_xpath("//input[@id='pmethod23']")
shippay.click()
sleep(5)
sleep(10)
print("Ist sleep")
sleep(10)
print("2nd sleep")

shipplace=driver.find_element_by_xpath("//button[@class='btn  regular-button regular-main-button place-order submit']")
shipplace.click()
sleep(30)
print("3rd sleep")
pinvoice=driver.find_element_by_xpath("//h2[@class='invoice']")
str1=pinvoice.text
print(str1)

#driver.("arguments[0].scrollIntoView(true);",shipdel)
#driver.sendKeys(Keys.PAGE_DOWN);
# if(shipdel.is_enabled()):
#     print ("ship delivary selected")
# else:
#     shipdel.click()

# shippay=driver.find_elements_by_xpath("//span[@class='payment-title']")
# ActionChains(driver).move_to_element(shippay).perform()
# #driver.execute_script("arguments[0].scrollIntoView();",shippay);
# if(shippay.isEnabledFor()):
#     print ("ship pay selected")
# else:
#     shipdel.click()

