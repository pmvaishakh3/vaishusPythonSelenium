Skip to content


Features 
Business 
Explore 
Marketplace 
Pricing 
This repository
 
Sign in or Sign up 


 Watch 
0 
 Star 
0 
 Fork 
0 

kishlaymishra19/SeleniumPythonTutorial 
 Code 
 Issues 0 
 Pull requests 0 
 Projects 0 
 Insights 
Branch: master 
Find file 
Copy path 
SeleniumPythonTutorial/SeleniumPython3Tutorial/PageObjectModel/pythonTest.py 
b0da9d4 on Sep 11 2017 
 kishlaymishra19 Add files via upload 
1 contributor 
 
Raw
Blame
History
   
42 lines (32 sloc) 1.4 KB 

'''

Created on Sep 7, 2017



@author: kishlay.mishra

'''

import unittest


from selenium import webdriver


import page



class PythonOrgSearch(unittest.TestCase):

    """A sample test class to show how page object works"""



    def setUp(self):

        self.driver=webdriver.Chrome("C:\\Users\\kishlay.mishra\\Downloads\\chromedriver.exe")

        self.driver.get("http://www.python.org")



    def test_search_in_python_org(self):

        """

        Tests python.org search feature. Searches for the word "pycon" then verified that some results show up.

        Note that it does not look for any particular text in search results page. This test verifies that

        the results were not empty.

        """



        #Load the main page. In this case the home page of Python.org.

        main_page = page.MainPage(self.driver)

        #Checks if the word "Python" is in title

        assert main_page.is_title_matches(), "python.org title doesn't match."

        #Sets the text of search textbox to "pycon"

        main_page.search_text_element = "pycon"

        main_page.click_go_button()

        search_results_page = page.SearchResultsPage(self.driver)

        #Verifies that the results page is not empty

        assert search_results_page.is_results_found(), "No results found."



    def tearDown(self):

        self.driver.close()



if __name__ == "__main__":

    unittest.main(verbosity=2)
� 2018 GitHub, Inc.
Terms
Privacy
Security
Status
Help
 
Contact GitHub
API
Training
Shop
Blog
About

Press h to open a hovercard with more details. 