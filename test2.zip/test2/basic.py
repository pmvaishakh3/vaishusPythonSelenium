from selenium import  webdriver
from selenium.webdriver.common.keys import  Keys
from selenium.webdriver.support.ui import Select
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
from re import search
from gettext import Catalog

opt=webdriver.ChromeOptions()
opt.add_argument('--disable-extensions')
opt.add_argument('--start-maximized')
opt.add_argument('disable-infobars')
opt.add_argument('--ignore-certificate-errors')
opt.add_argument("--test-type")
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path,chrome_options=opt)
driver.implicitly_wait(15)
def launchwebsite():
    driver.get("https://demostore.x-cart.com/")
    print(driver.title)
def Catalog():
    result=driver.find_element_by_xpath("//div[@class='collapse navbar-collapse']//span[text()='Catalog']")
    Catalog=driver.find_element_by_xpath("//li[@class='leaf has-sub']//span[text()='iGoods - Product Filter']")
    ActionChains(driver).move_to_element(result).click(Catalog).perform() 
def searchText():   
    sleep(20)
    list=driver.find_elements_by_xpath("//input[@placeholder='Search items...']")
    list[0].send_keys("iphone")
    driver.find_element_by_xpath("//div[@id='search']//button[@class='btn  regular-button submit-button submit']").click()    
    #textvalve=driver.find_element_by_xpath("//div[@class='head-h2 ']").text
    #print(textvalve)
def searchProduct():
    results=driver.find_elements_by_xpath("//li[@class='product-cell box-product']")
    addToCart=driver.find_element_by_xpath("//span[text()='Add to cart']")
    sleep(5)
    ActionChains(driver).move_to_element(results[0]).perform()
    addToCart.click()
    #driver.execute_script("window.scrollTo(0,400 )")
    #driver.find_element_by_xpath("//a[text()='Apple iPhone SE [Options & Attributes] [Variants] [Tabs]']")
    #driver.find_element_by_xpath("//a[text()='Apple iPhone SE [Options & Attributes] [Variants] [Tabs]']").click()
def addtocart():    
    driver.find_element_by_xpath("//span[text()='Add to cart']").click()
def checkout():   
    sleep(5) 
    driver.find_element_by_xpath("//div[@class='item-buttons']//span[text()='Checkout']").click()
    #driver.find_element_by_xpath("//span[text()='Checkout']").click()
def hding():
    h3=driver.find_element_by_xpath("//div[@class='signin-wrapper-heading']/h3[text()='Log in to your account']").text
    print(h3)
def signup():
    driver.find_element_by_xpath("//div[@class='header_bar-sign_in']").click()
        
def lgIn():    
    email=driver.find_element_by_xpath("//input[@id='login-email']")
    email.send_keys("ashwini@gmail.com")
    pswd=driver.find_element_by_xpath("//input[@type='password']")
    pswd.send_keys("anusha23")
    driver.find_element_by_xpath("//table[@class='login-form']//button[@class='btn  regular-button  submit']").click()
def shippingAddress():
    sleep(5)
    driver.find_element_by_xpath("//input[@name='shippingAddress[firstname]']").clear()
    driver.find_element_by_xpath("//input[@name='shippingAddress[firstname]']").send_keys("ishu")
    driver.find_element_by_id("shippingaddress-lastname").clear()
    driver.find_element_by_id("shippingaddress-lastname").send_keys("kasetty")
    driver.find_element_by_id("shippingaddress-street").clear()
    driver.find_element_by_id("shippingaddress-street").send_keys("npnagar")
    driver.find_element_by_id("shippingaddress-city").clear()
    driver.find_element_by_id("shippingaddress-city").send_keys("Banglore")
    driver.find_element_by_id("shippingaddress-country-code").send_keys("India")
    sleep(20)
    select=Select(driver.find_element_by_id("shippingaddress-state-id"))
    select.select_by_visible_text("Karnataka")    
    driver.find_element_by_id("shippingaddress-state-id").send_keys("115")
    driver.find_element_by_id("shippingaddress-zipcode").clear()
    driver.find_element_by_id("shippingaddress-zipcode").send_keys("90001")
    driver.find_element_by_id("shippingaddress-phone").clear()
    driver.find_element_by_id("shippingaddress-phone").send_keys("9676308154")
    sleep(15)
def deliveryMethods():
    driver.find_element_by_xpath("//label[@title='Local pickup']").click()
def paymentMethods():
    sleep(10)
    driver.find_element_by_xpath("//span[text()='X-Payments DEMO']").click()
    sleep(15)
    driver.find_element_by_xpath("//span[contains(text(),'Place order')]").click()
def printInvoice():    
    driver.find_element_by_xpath("//span[text()='Print invoice']").click()
def  Myaccount():
    result=driver.find_element_by_xpath("//div[@class='collapse navbar-collapse']//span[text()='My Account']")
    Myaddressbook=driver.find_element_by_xpath("//li[@class='leaf has-sub']//span[text()='My address book']")  
    ActionChains(driver).move_to_element(result).click(Myaddressbook).perform()
def addaddress():
    driver.find_element_by_xpath("//span[text()='Add new address']").click() 
    driver.find_element_by_xpath("//input[@id='-firstname']").send_keys("sreesai")
    driver.find_element_by_id("-lastname").send_keys("ram")
    driver.find_element_by_id("-street").send_keys("sainagar")
    driver.find_element_by_id("-city").send_keys("Banglore")
    driver.find_element_by_id("-country-code").send_keys("India")
    sleep(15)
    select=Select(driver.find_element_by_id("-state-id"))
    select.select_by_visible_text("Karnataka")    
    #driver.find_element_by_id("shippingaddress-state-id").send_keys("115")
    driver.find_element_by_id("-zipcode").clear()
    driver.find_element_by_id("-zipcode").send_keys("90001")
    driver.find_element_by_id("-phone").clear()
    driver.find_element_by_id("-phone").send_keys("9676308154")
    driver.find_element_by_xpath("//span[text()='Save changes']").click() 
    sleep(5)
    driver.find_element_by_xpath("//div[@class='address-box  selected']//div[@class='delete-action']").click()
    driver.switch_to_alert().accept()
    
    
#def yourcart():
    #driver.find_element_by_xpath("//div[@title='Your cart']").click()    
    #driver.close()
    #driver.quit()
#launchwebsite()
#searchText()
#Catalog()
#Myaccount()
#searchProduct()
#addtocart()
#checkout()
#hding()
#lgIn()
#shippingAddress()
#deliveryMethods()
#paymentMethods()

launchwebsite()
signup()
lgIn()
#Myaccount()
#addaddress()
#yourcart()
searchText()
#searchProduct()
#addtocart()
#checkout()
#shippingAddress()
#paymentMethods()
#printInvoice()
