
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from unittest.test.testmock.testpatch import function

chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
#         driver=webdriver.Chrome(chrome_path)
#         return driver
driver=webdriver.Chrome(chrome_path)
driver.implicitly_wait(15)
driver.maximize_window()

def wb():
        #driver=webdriver.Chrome(chrome_path)
        driver.implicitly_wait(15)
        driver.maximize_window()
        driver.get("https://demostore.x-cart.com/")
        #print (driver.title)
        #testuserdata()
        #chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
        
def login():
            sleep(10)
            cartsign=driver.find_elements_by_xpath("//button[@class='btn  regular-button  popup-button popup-login']")
            cartsign[1].click()
            sleep(10)
            cartemail=driver.find_element_by_xpath("//input[@id='login-email']")
            #cartemail.click()
            cartemail.clear()
            cartemail.send_keys("vaishu1@gmail.com")
            cartpass=driver.find_element_by_xpath("//input[@id='login-password']")
            #cartpass.click()
            cartpass.clear()
            cartpass.send_keys("123")
            cartsignin=driver.find_elements_by_xpath("//button[@class='btn  regular-button  submit']/span")
            #cartpass.click()
            #cartsign[1].click()
            cartsignin[1].click()
            sleep(10)
        
def xcart():
            cartsearch=driver.find_element_by_xpath("//div[@class='table-value substring-value']/span/input")
            cartsearch.send_keys("toys")
            cartsearch1=driver.find_element_by_xpath("//button[@class='btn  regular-button submit-button submit']")
            cartsearch1.click()
            cartsearch2=driver.find_element_by_xpath("//a[@class='product-thumbnail next-previous-assigned']")
            cartsearch2.click()
            sleep(10)
            cartsearch3=driver.find_element_by_xpath("//button[@class='btn  regular-button regular-main-button add2cart submit']")
            cartsearch3.click()
            sleep(30)
            checkoutorder=driver.find_elements_by_xpath("//a[@class='regular-main-button checkout']/span")
        #print (len(checkoutorder))
            checkoutorder[1].click()
        
def userdata():
            shipfname=driver.find_element_by_xpath("//input[@id='shippingaddress-firstname']")
            shipfname.send_keys("kumar")
            shiplname=driver.find_element_by_xpath("//input[@id='shippingaddress-lastname']")
            shiplname.send_keys("kishor")
            shipadd=driver.find_element_by_xpath("//input[@id='shippingaddress-street']")
            shipadd.send_keys("EC")
            shipstate=driver.find_element_by_xpath("//select[@id='shippingaddress-state-id']")
            shipstate.send_keys("Karnataka")
            shippin=driver.find_element_by_xpath("//input[@id='shippingaddress-zipcode']")
            shippin.clear()
            shippin.send_keys("560100")
            shipdel=driver.find_element_by_xpath("//input[@id='method8']")
            shipdel.click()
        # sleep(5)
        # sleep(10)
        # print("Ist sleep")
            sleep(20)
            # print("2nd sleep")
            shippay=driver.find_element_by_xpath("//input[@id='pmethod23']")
            shippay.click()
            sleep(20)
            shipplace=driver.find_element_by_xpath("//button[@class='btn  regular-button regular-main-button place-order submit']")
            shipplace.click()
            sleep(30)
            pinvoice=driver.find_element_by_xpath("//h2[@class='invoice']")
            str1=pinvoice.text
            print(str1)
            
wb()
login()
xcart()
userdata()

    
def tearDown(self):
        self.driver.quit()