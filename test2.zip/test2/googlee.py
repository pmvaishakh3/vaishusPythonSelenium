from selenium import webdriver
from selenium.webdriver.common.keys import Keys
#from test2.google import listsearch

opt=webdriver.ChromeOptions()
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path,chrome_options=opt)
driver.implicitly_wait(15)

driver.get("https://www.google.com")

gool = driver.find_element_by_id('lst-ib')
gool.send_keys("jai")
gool.send_keys(Keys.ENTER)

listsearch=driver.find_elements_by_xpath("//h3[@class='r']/a")
print(len(listsearch))
listsearch[-1].click()
#gool = driver.find_element_by_id("lst-ib")
#gool.send_keys("kumar")
#gool.send_keys(Keys.ENTER)
