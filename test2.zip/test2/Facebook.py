from selenium import webdriver
from selenium.webdriver.common.keys import Keys


opt=webdriver.ChromeOptions()
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path,chrome_options=opt)

#driver.get("https://www.google.com")
#print(driver.title)
#driver.get("https://www.gmail.com")
#print(driver.title)
user = " "
pwd = " "
driver.get("https://www.facebook.com")
#print(driver.title)
#assert "Facebook" in driver.title
elem = driver.find_element_by_id("email")
elem.send_keys("user")
elem = driver.find_element_by_id("pass")
elem.send_keys("pwd")
elem =driver.find_element_by_id("u_0_2")
elem.click()
elem.send_keys(Keys.RETURN)
driver.close()
driver.quit()
