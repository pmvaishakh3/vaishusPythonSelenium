from selenium import webdriver
from selenium.webdriver.common.keys import Keys

opt=webdriver.ChromeOptions()
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path,chrome_options=opt)
driver.implicitly_wait(15)

driver.get("https://www.google.com")

elem = driver.find_element_by_id("lst-ib")
elem.send_keys("Vaishakh")
elem.send_keys(Keys.ENTER)
#elem.close()
#elem = driver.find_element_by_name("btnK")
#elem.click()
#elem = driver.find_element_by_class("")
#elem.find_element(By.linkText("tesh3ter - Wiktionary"), value)
#elem.click("contains(text(),'val')")
#elem.send_keys("pwd")

listsearch=driver.find_elements_by_xpath("//h3[@class='r']/a")
print(len(listsearch))
listsearch[0].click()
searchfound=driver.find_element_by_xpath("//a[@class='product-thumbnail next-previous-assigned']")
searchfound[0].click()
#listsearch=driver.find_element_by_xpath(xpath)
#driver.close()
#driver.quit()
#listsearch=driver.find_element_by_xpath(xpath)




