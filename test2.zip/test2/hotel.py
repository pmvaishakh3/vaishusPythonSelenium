from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#opt=webdriver.ChromeOptions()
chrome_path="C:\\Users\\VAISHU\\Downloads\\chromedriver_win32\\chromedriver.exe"
driver=webdriver.Chrome(chrome_path)
driver.implicitly_wait(15)

driver.get("https://www.phptravels.net")

#hotloc= driver.find_element_by_id("//d[@id='select2-drop-mask']//following-sibling::div[1]//input")
hotloclist=driver.find_element_by_id("//div[@id='select2-drop-mask']")
#hotloclist= driver.find_element_by_id("//div[@id='s2id_autogen10']")
hotloclist= driver.find_elements_by_xpath("//input[@class='select2-input']")
#hotloclist.click()
hotloclist[6].click()
#hotloclist1 = driver.find_elements_by_xpath("//input[@class='select2-input']")
#hotloclist1[0].click()
hotloclist.send_keys("hai")
