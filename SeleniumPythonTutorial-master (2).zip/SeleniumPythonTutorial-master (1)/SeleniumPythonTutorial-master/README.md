# SeleniumPythonTutorial
Repo for some Selenium with Python examples
