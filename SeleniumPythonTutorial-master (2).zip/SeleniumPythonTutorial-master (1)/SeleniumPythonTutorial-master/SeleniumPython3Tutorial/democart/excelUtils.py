'''
Created on Sep 18, 2017

@author: kishlay.mishra
'''
from openpyxl import load_workbook


class Excel_Data:
    
    def get_data(self,val):
        wb = load_workbook(filename = 'input.xlsx')
        ws=wb['Data']
        ws.sheet_properties.tabColor = "1D0E98"
        res=''
        if val=='UserName':
            res=ws['A'+str(self.roW)].value
            print(res)
        elif val=='Password':
            res=ws['B'+str(self.roW)].value
        elif val=='Emailid':
            res=ws['C'+str(self.roW)].value
        elif val=='FirstName':
            res=ws['D'+str(self.roW)].value
        elif val=='LastName':
            res=ws['E'+str(self.roW)].value
        elif val=='Address':
            res=ws['F'+str(self.roW)].value
        elif val=='City':
            res=ws['G'+str(self.roW)].value
        elif val=='Country':
            res=ws['H'+str(self.roW)].value
        elif val=='State':
            res=ws['I'+str(self.roW)].value
        elif val=='Pincode':
            res=ws['J'+str(self.roW)].value
        elif val=='PhoneNumber':
            res=ws['K'+str(self.roW)].value
        
        wb.close()
        
        return res
    
    def write_result(self,val):
        wbR = load_workbook(filename = 'input.xlsx')
        dest_filename = 'input.xlsx'
        
        sheetR=wbR.active
        
        if('Result' in wbR.sheetnames):
            sheetR=wbR['Result']
        else:
            sheetR=wbR.create_sheet(title='Result')
        
        sheetR.sheet_properties.tabColor = "d6ca9e"
            
        sheetR['A3']=val
        wbR.save(filename = dest_filename)
        