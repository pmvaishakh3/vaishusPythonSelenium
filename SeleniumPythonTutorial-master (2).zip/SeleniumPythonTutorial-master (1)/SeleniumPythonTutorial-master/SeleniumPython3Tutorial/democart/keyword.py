#from openpyxl import workbook
import xlrd 
#
# class Excel_Data1:
#
#    def get_data(self):
#     wb = workbook(filename = 'k1.xlsx')
#     ws=wb['TCER']
#
#     max_col=ws.max_column
#     print (max_col)
#

d = {}
wb = xlrd.open_workbook('k1.xlsx')
sh = wb.sheet_by_index(2)
for i in range(138):
    cell_value_class = sh.cell(i,2).value
    cell_value_id = sh.cell(i,0).value
    d[cell_value_class] = cell_value_idd = {}
